package torrent

import "github.com/anacrolix/missinggo"

type (
	multiLess = missinggo.MultiLess
	cmper     = missinggo.SameLessFunc
)
