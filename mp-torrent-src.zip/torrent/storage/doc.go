// Package storage implements storage backends for package torrent.
package storage
