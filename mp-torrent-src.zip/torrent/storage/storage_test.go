package storage

import (
	_ "github.com/anacrolix/envpprof"
)
