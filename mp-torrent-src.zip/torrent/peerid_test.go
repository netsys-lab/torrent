package torrent

// func TestPeerIdString(t *testing.T) {
// 	for _, _case := range []struct {
// 		id string
// 		s  string
// 	}{
// 		{"\x1cNJ}\x9c\xc7\xc4o\x94<\x9b\x8c\xc2!I\x1c\a\xec\x98n", "\"\x1cNJ}\x9c\xc7\xc4o\x94<\x9b\x8c\xc2!I\x1c\a\xec\x98n\""},
// 		{"-FD51W\xe4-LaZMk0N8ZLA7", "-FD51W\xe4-LaZMk0N8ZLA7"},
// 	} {
// 		var pi PeerID
// 		missinggo.CopyExact(&pi, _case.id)
// 		assert.EqualValues(t, _case.s, pi.String())
// 		assert.EqualValues(t, fmt.Sprintf("%q", _case.s), fmt.Sprintf("%q", pi))
// 	}
// }
